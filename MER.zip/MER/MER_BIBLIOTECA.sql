# declaremos el nombre de la base y aseguremos sea nueva
CREATE DATABASE IF NOT EXISTS biblioteca;
# una vez revisado que no existe la vamos a utilizar
USE biblioteca;

#vamos a crear la primera tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS usuarios(
Id_usuario INT UNIQUE PRIMARY KEY,
Nombre_usuario VARCHAR(100) NOT NULL,
Direccion_usuario VARCHAR(150) NOT NULL
);

#creamos la segunda tabla independiente
CREATE TABLE IF NOT EXISTS libros(
Id_libro INT UNIQUE PRIMARY KEY,
Titulo_libro VARCHAR(50) NOT NULL,
Autor_libro VARCHAR(50) NOT NULL,
AñoPublicacion_libro DATE NOT NULL
);

#vamos a definir los CONSTRAINT para las llaves foraneas
CREATE TABLE IF NOT EXISTS prestamos(
Id_prestamo INT UNIQUE PRIMARY KEY,
Fecha_prestamo DATE NOT NULL,
FechaDevolucion_prestamo DATE NOT NULL,

Id_usuario INT(50) NOT NULL,
Id_libro INT(50) NOT NULL,

CONSTRAINT fk_factura_usuarios FOREIGN KEY(Id_usuario) REFERENCES usuarios(Id_usuario),
CONSTRAINT fk_factura_libros FOREIGN KEY(Id_libro) REFERENCES libros(Id_libro)
);


