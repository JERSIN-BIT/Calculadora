# declaremos el nombre de la base y aseguremos sea nueva
CREATE DATABASE IF NOT EXISTS universidad;
# una vez revisado que no existe la vamos a utilizar
USE universidad;

#vamos a crear la primera tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS estudiantes(
NumeroMatricula_estudiante INT UNIQUE PRIMARY KEY,
Nombre_estudiante VARCHAR(50) NOT NULL,
Correo_estudiante VARCHAR(50) NOT NULL
);
#creamos la segunda tabla independiente
CREATE TABLE IF NOT EXISTS profesores(
CodigoCurso_profesor INT UNIQUE PRIMARY KEY,
Nombre_profesor VARCHAR(10) NOT NULL,
Especialidad_profesor VARCHAR(20)
);

#vamos a definir los CONSTRAINT para las llaves foraneas
CREATE TABLE IF NOT EXISTS cursos(
CodigoCurso_curso INT UNIQUE PRIMARY KEY,
Nombre_curso VARCHAR(30) NOT NULL,
NumeroCredito_curso INT(30) NOT NULL,
CodigoCurso_profesor INT(20) NOT NULL,

CONSTRAINT fk_curso_profesor FOREIGN KEY(CodigoCurso_profesor) REFERENCES profesores(CodigoCurso_profesor)
);

#vamos a definir los CONSTRAINT para las llaves foraneas
CREATE TABLE IF NOT EXISTS matriculas(
IdPago_matricula INT UNIQUE PRIMARY KEY,
NumeroMatricula_estudiante INT(20) NOT NULL,
CodigoCurso_curso INT(20) NOT NULL,

CONSTRAINT fk_matricula_estudiante FOREIGN KEY(NumeroMatricula_estudiante) REFERENCES estudiantes(NumeroMatricula_estudiante),
CONSTRAINT fk_matricula_curso FOREIGN KEY(CodigoCurso_curso) REFERENCES cursos(CodigoCurso_curso)

);


